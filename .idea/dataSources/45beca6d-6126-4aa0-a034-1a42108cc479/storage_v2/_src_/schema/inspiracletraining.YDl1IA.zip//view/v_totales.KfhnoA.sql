CREATE VIEW v_totales AS
  SELECT
    1 AS `total`,
    1 AS `id_pregunta`,
    1 AS `id_usuario`;

