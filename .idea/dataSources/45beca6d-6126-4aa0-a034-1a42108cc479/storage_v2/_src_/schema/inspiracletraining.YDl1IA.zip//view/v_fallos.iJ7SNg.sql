CREATE VIEW v_fallos AS
  SELECT
    count(`re`.`id_pregunta`) AS `count(re.id_pregunta)`,
    `re`.`id_pregunta`        AS `id_pregunta`,
    `r`.`id_usuario`          AS `id_usuario`
  FROM ((`inspiracletraining`.`resultados_respuestas` `rr`
    JOIN `inspiracletraining`.`respuestas` `re` ON ((`re`.`id_respuesta` = `rr`.`id_respuesta`))) JOIN
    `inspiracletraining`.`resultados` `r` ON ((`r`.`id_resultado` = `rr`.`id_resultado`)))
  WHERE (`re`.`correcta` = 0)
  GROUP BY `re`.`id_pregunta`, `r`.`id_usuario`;

