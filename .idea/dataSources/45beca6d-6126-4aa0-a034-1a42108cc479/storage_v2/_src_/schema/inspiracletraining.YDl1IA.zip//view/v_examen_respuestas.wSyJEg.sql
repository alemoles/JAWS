CREATE VIEW v_examen_respuestas AS
  SELECT
    `e`.`id_examen`    AS `id_examen`,
    `p`.`id_pregunta`  AS `id_pregunta`,
    `r`.`id_resultado` AS `id_resultado`,
    `r`.`id_usuario`   AS `id_usuario`,
    `u`.`nivel`        AS `nivel`,
    (SELECT `resp`.`correcta`
     FROM (`inspiracletraining`.`respuestas` `resp`
       JOIN `inspiracletraining`.`resultados_respuestas` `resul_resp`
         ON ((`resp`.`id_respuesta` = `resul_resp`.`id_respuesta`)))
     WHERE ((`resul_resp`.`id_resultado` = `r`.`id_resultado`) AND (`resp`.`id_pregunta` = `ep`.`id_pregunta`))
     LIMIT 1)          AS `correcta`
  FROM ((((`inspiracletraining`.`preguntas` `p`
    JOIN `inspiracletraining`.`examenes_preguntas` `ep` ON ((`ep`.`id_pregunta` = `p`.`id_pregunta`))) JOIN
    `inspiracletraining`.`examenes` `e` ON ((`e`.`id_examen` = `ep`.`id_examen`))) LEFT JOIN
    `inspiracletraining`.`resultados` `r` ON ((`r`.`id_examen` = `e`.`id_examen`))) LEFT JOIN
    `inspiracletraining`.`usuarios` `u` ON ((`r`.`id_usuario` = `u`.`id_usuario`)));

