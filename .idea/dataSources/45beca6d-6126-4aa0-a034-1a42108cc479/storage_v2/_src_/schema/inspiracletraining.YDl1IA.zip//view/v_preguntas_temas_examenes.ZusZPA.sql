CREATE VIEW v_preguntas_temas_examenes AS
  SELECT
    1 AS `id_tema`,
    1 AS `nombre_tema`,
    1 AS `activo_tema`,
    1 AS `id_unidad`,
    1 AS `nombre_unidad`,
    1 AS `activo_unidad`,
    1 AS `id_anyo`,
    1 AS `nombre_anyo`,
    1 AS `id_pregunta`,
    1 AS `enunciado`,
    1 AS `activo_pregunta`,
    1 AS `id_examen`,
    1 AS `titulo`,
    1 AS `activo_examen`;

