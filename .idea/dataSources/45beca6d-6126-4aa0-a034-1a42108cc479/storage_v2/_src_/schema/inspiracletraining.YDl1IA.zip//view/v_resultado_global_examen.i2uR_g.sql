CREATE VIEW v_resultado_global_examen AS
  SELECT
    1 AS `id_examen`,
    1 AS `id_resultado`,
    1 AS `titulo`,
    1 AS `id_curso`,
    1 AS `id_tema`,
    1 AS `id_unidad`,
    1 AS `id_anyo`,
    1 AS `id_pregunta`,
    1 AS `id_usuario`,
    1 AS `fecha`,
    1 AS `correcta`;

