CREATE VIEW v_preguntasreales AS
  SELECT
    1 AS `id_curso`,
    1 AS `nombreCurso`,
    1 AS `id_tema`,
    1 AS `nombreTema`,
    1 AS `id_unidad`,
    1 AS `nombreUnidad`,
    1 AS `id_anyo`,
    1 AS `nombreAnyo`,
    1 AS `id_pregunta`;

