CREATE VIEW v_total AS
  SELECT
    1 AS `total`,
    1 AS `id_pregunta`,
    1 AS `id_usuario`;

