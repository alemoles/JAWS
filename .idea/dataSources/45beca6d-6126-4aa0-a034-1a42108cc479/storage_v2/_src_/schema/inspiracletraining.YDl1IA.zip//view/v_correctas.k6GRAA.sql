CREATE VIEW v_correctas AS
  SELECT
    count(`rr`.`id_respuesta`) AS `total`,
    `res`.`id_pregunta`        AS `id_pregunta`,
    `r`.`id_usuario`           AS `id_usuario`
  FROM ((`inspiracletraining`.`resultados_respuestas` `rr`
    JOIN `inspiracletraining`.`respuestas` `res` ON ((`res`.`id_respuesta` = `rr`.`id_respuesta`))) JOIN
    `inspiracletraining`.`resultados` `r` ON ((`r`.`id_resultado` = `rr`.`id_resultado`)))
  WHERE (`res`.`correcta` = 1)
  GROUP BY `res`.`id_pregunta`, `r`.`id_usuario`;

