CREATE VIEW v_preguntas_con_temas AS
  SELECT
    `e`.`id_examen`   AS `id_examen`,
    `e`.`autor`       AS `autor`,
    `e`.`tiempo`      AS `tiempo`,
    `e`.`titulo`      AS `titulo`,
    `e`.`activo`      AS `exa_activo`,
    `t`.`nombre`      AS `nom_tema`,
    `t`.`id_tema`     AS `id_tema`,
    `t`.`activo`      AS `tem_activo`,
    `u`.`nombre`      AS `nom_unidad`,
    `u`.`id_unidad`   AS `id_unidad`,
    `u`.`activo`      AS `uni_activo`,
    `a`.`nombre`      AS `nom_anyo`,
    `a`.`id_anyo`     AS `id_anyo`,
    `p`.`id_pregunta` AS `id_pregunta`,
    `p`.`enunciado`   AS `enunciado`,
    `p`.`anotacion`   AS `anotacion`,
    `p`.`explicacion` AS `explicacion`,
    `p`.`activo`      AS `pre_activo`
  FROM ((((((`inspiracletraining`.`examenes` `e`
    JOIN `inspiracletraining`.`examenes_preguntas` `ep` ON ((`e`.`id_examen` = `ep`.`id_examen`))) JOIN
    `inspiracletraining`.`preguntas` `p` ON ((`p`.`id_pregunta` = `ep`.`id_pregunta`))) JOIN
    `inspiracletraining`.`anyos_preguntas` `ap` ON ((`ap`.`id_pregunta` = `ap`.`id_pregunta`))) JOIN
    `inspiracletraining`.`anyos` `a` ON ((`a`.`id_anyo` = `ap`.`id_anyo`))) JOIN `inspiracletraining`.`unidades` `u`
      ON ((`u`.`id_unidad` = `a`.`id_unidad`))) JOIN `inspiracletraining`.`temas` `t`
      ON ((`t`.`id_tema` = `u`.`id_tema`)));

