CREATE VIEW v_min_fecha_cal AS
  SELECT
    min(`cd`.`fecha`)    AS `min_fecha`,
    `cd`.`id_calendario` AS `id_calendario`
  FROM `inspiracletraining`.`calendario_dias` `cd`
  GROUP BY `cd`.`id_calendario`;

