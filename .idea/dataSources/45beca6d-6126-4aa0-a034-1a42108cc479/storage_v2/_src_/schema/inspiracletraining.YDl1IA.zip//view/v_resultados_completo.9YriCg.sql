CREATE VIEW v_resultados_completo AS
  SELECT
    1 AS `id_resultado`,
    1 AS `id_usuario`,
    1 AS `titulo`,
    1 AS `autor`,
    1 AS `id_examen`,
    1 AS `fecha`,
    1 AS `tiempo_restante`,
    1 AS `finalizado`,
    1 AS `puntos`,
    1 AS `acertadas`,
    1 AS `fallidas`;

